if (!(/^(www\.|)canarytokens\.(com|org)$/i.test(document.domain))){
  $('#mainsite').removeClass('hidden');
}
